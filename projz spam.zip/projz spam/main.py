import projz as lib
from asyncio import run,  gather, create_task
from os import system as s
from colored import fore, style, attr
client = lib.ZClient(establish_websocket=True)
attr(0)
print(fore.BLUE + style.BOLD)



projz = """
╔╗╔╗╔╗══╗═╗ ╔╗╔╗╔╗╔╦╗╔═╔╗
║║╠╝║║╔╗║╔╝ ╚╗║║╠╣║║║╠═╠╝
╠╝╠╗╚╝╚═╝╚═ ╚╝╠╝║║║║║╚═╠╗
"""
s("cls")
print(f"""
	\n{projz}\n
	Made by Xsarz
	GitHub: https://github.com/xXxCLOTIxXx
	Telegram: https://t.me/DxsarzUnion
	YouTube: https://www.youtube.com/channel/UCNKEgQmAvt6dD7jeMLpte9Q\n\n
	""")

async def login():
	while True:
		try:
			await client.login(email=input("Gmail>> "),password=input("Password>> ")) #login func
			print("\nLogined succesful\n")
			break
		except Exception as error:
			print(error)

async def spam():
	my_chats = await client.get_my_chats(size=1000)
	for number, chat in enumerate(my_chats, 1):
		print(f"{number}.{chat.title}")
	while True:
		try:
			chatId = my_chats[int(input("Select chat>> ")) - 1].thread_id #select chat
			break
		except ValueError:
			print('\nPlease enter an integer\n')
		except Exception as error:
			print(error)
	message = input("Message>> ") #input message

	while True:
		await gather(*[
			create_task(
				client.send_message(thread_id=chat_Id, content=message)
				)for _ in range(1000)])
		print("Spam started...")


if __name__ == "__main__":
	run(login()) #login
	run(spam()) #start spam